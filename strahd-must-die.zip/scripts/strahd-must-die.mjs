const MODULE_ID = "strahd-must-die";
const THEME_CLASS = "smd-journal";
const SETTING_THEME = "gothicTheme";

function journalOf(document) {
  if (!document) return null;
  return document.documentName === "JournalEntryPage" ? document.parent : document;
}

function isThemed(document) {
  return Boolean(journalOf(document)?.flags?.[MODULE_ID]?.themed);
}

function themeEnabled() {
  try {
    return game.settings.get(MODULE_ID, SETTING_THEME);
  } catch {
    return true;
  }
}

function applyTheme(application, element) {
  const root = element instanceof HTMLElement ? element : element?.[0] ?? application?.element;
  if (!(root instanceof HTMLElement)) return;
  root.classList.toggle(THEME_CLASS, themeEnabled() && isThemed(application?.document));
}

function rerenderThemedSheets() {
  for (const application of foundry.applications.instances.values()) {
    if (isThemed(application.document)) application.render();
  }
}

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, SETTING_THEME, {
    name: "STRAHD.Settings.Theme.Name",
    hint: "STRAHD.Settings.Theme.Hint",
    scope: "client",
    config: true,
    type: Boolean,
    default: true,
    onChange: rerenderThemedSheets
  });
});

Hooks.on("renderJournalEntrySheet", applyTheme);
Hooks.on("renderJournalEntryPageSheet", applyTheme);
