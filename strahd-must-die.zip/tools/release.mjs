import { createWriteStream } from "node:fs";
import { copyFile, mkdir, readFile, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import archiver from "archiver";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DIST = path.join(ROOT, "dist");
const INCLUDE_FILES = ["module.json", "README.md", "CHANGELOG.md", "LICENSE.md"];
const INCLUDE_DIRS = ["assets", "fonts", "lang", "packs", "scripts", "styles"];
const PACK_IGNORE = ["**/LOCK", "**/LOG", "**/LOG.old"];

const manifest = JSON.parse(await readFile(path.join(ROOT, "module.json"), "utf8"));
const expectedDownload = `https://github.com/fernandowrpg/strahd-must-die/releases/download/v${manifest.version}/module.zip`;
if (manifest.download !== expectedDownload) {
  throw new Error(`module.json "download" must be ${expectedDownload} for version ${manifest.version}`);
}

await rm(DIST, { recursive: true, force: true });
await mkdir(DIST, { recursive: true });

const zipPath = path.join(DIST, "module.zip");
const output = createWriteStream(zipPath);
const archive = archiver("zip", { zlib: { level: 9 } });
const done = new Promise((resolve, reject) => {
  output.on("close", resolve);
  archive.on("error", reject);
});
archive.pipe(output);
for (const file of INCLUDE_FILES) archive.file(path.join(ROOT, file), { name: file });
for (const dir of INCLUDE_DIRS) archive.glob(`${dir}/**/*`, { cwd: ROOT, ignore: PACK_IGNORE, dot: false });
await archive.finalize();
await done;

await copyFile(path.join(ROOT, "module.json"), path.join(DIST, "module.json"));
console.log(`dist/module.zip (${(archive.pointer() / 1024 / 1024).toFixed(2)} MB) and dist/module.json ready for v${manifest.version}`);
