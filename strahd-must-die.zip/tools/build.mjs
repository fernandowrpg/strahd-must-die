import { createHash } from "node:crypto";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { compilePack } from "@foundryvtt/foundryvtt-cli";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SRC = path.join(ROOT, "src");
const JSON_OUT = path.join(ROOT, "build", "json");
const PACKS_OUT = path.join(ROOT, "packs");

const manifest = JSON.parse(await readFile(path.join(ROOT, "module.json"), "utf8"));
const MODULE_ID = manifest.id;
const MODULE_PATH = `modules/${MODULE_ID}`;
const CORE_VERSION = "13.351";
const THEME_COLOR = "#5c0010";

const book = await readJson("book.json");
const omen = await readJson("omen-cards.json");
const tables = await readJson("tables.json");

const BASE62 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

function makeId(key) {
  const bytes = createHash("sha256").update(`${MODULE_ID}:${key}`).digest();
  let id = "";
  for (let i = 0; i < 16; i++) id += BASE62[bytes[i] % 62];
  return id;
}

async function readJson(file) {
  return JSON.parse(await readFile(path.join(SRC, file), "utf8"));
}

function stats() {
  return {
    coreVersion: CORE_VERSION,
    systemId: null,
    systemVersion: null,
    createdTime: null,
    modifiedTime: null,
    lastModifiedBy: null,
    compendiumSource: null,
    duplicateSource: null,
    exportSource: null
  };
}

function slugify(text) {
  return text.replace(/\s+/g, "-").trim().toLowerCase().replace(/[^a-zA-Z0-9-]/g, "");
}

function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

const ids = {
  journalFolder: makeId("folder:journals"),
  entries: new Map(),
  pages: new Map(),
  tables: new Map(),
  decks: new Map([["omen-deck", makeId("cards:omen-deck")]])
};

for (const chapter of book) {
  ids.entries.set(chapter.slug, makeId(`journal:${chapter.slug}`));
  for (const page of chapter.pages) ids.pages.set(`${chapter.slug}/${page.slug}`, makeId(`page:${chapter.slug}/${page.slug}`));
}
for (const table of tables) ids.tables.set(table.slug, makeId(`table:${table.slug}`));
ids.tables.set("omen-cards", makeId("table:omen-cards"));

function entryUuid(chapter) {
  const id = ids.entries.get(chapter);
  if (!id) throw new Error(`Unknown journal entry "${chapter}"`);
  return `Compendium.${MODULE_ID}.journals.JournalEntry.${id}`;
}

function pageUuid(ref) {
  const [chapter] = ref.split("/");
  const id = ids.pages.get(ref);
  if (!id) throw new Error(`Unknown journal page "${ref}"`);
  return `${entryUuid(chapter)}.JournalEntryPage.${id}`;
}

function tableUuid(slug) {
  const id = ids.tables.get(slug);
  if (!id) throw new Error(`Unknown roll table "${slug}"`);
  return `Compendium.${MODULE_ID}.tables.RollTable.${id}`;
}

function deckUuid(slug) {
  const id = ids.decks.get(slug);
  if (!id) throw new Error(`Unknown card deck "${slug}"`);
  return `Compendium.${MODULE_ID}.omen-deck.Cards.${id}`;
}

function resolve(html) {
  return html
    .replace(/\{\{MOD\}\}/g, MODULE_PATH)
    .replace(/\{\{page:([^}]+)\}\}/g, (_, ref) => pageUuid(ref))
    .replace(/\{\{entry:([^}]+)\}\}/g, (_, ref) => entryUuid(ref))
    .replace(/\{\{table:([^}]+)\}\}/g, (_, ref) => tableUuid(ref))
    .replace(/\{\{deck:([^}]+)\}\}/g, (_, ref) => deckUuid(ref));
}

function cardTitle(card) {
  if (card.suit === "joker") return `${card.rank} | ${card.name}`;
  const suit = omen.suits[card.suit].label;
  return `${card.rank} of ${suit} | ${card.name}`;
}

function cardSlug(card) {
  return `${card.suit}-${card.rank}`.toLowerCase().replace(/\s+/g, "-");
}

function cardImage(card) {
  return `${MODULE_PATH}/assets/cards/${cardSlug(card)}.webp`;
}

function cardBody(card) {
  const effect = card.effect.map(p => `<p>${escapeHtml(p)}</p>`).join("");
  return `<p><span class="label">Passive:</span> ${escapeHtml(card.passive)}</p>`
    + `<p><span class="label">${escapeHtml(card.costLabel)}:</span> ${escapeHtml(card.cost)}</p>`
    + effect;
}

function suitCards(suit) {
  return omen.cards.filter(card => card.suit === suit);
}

function omenPageRef(card) {
  return `conspiracy-of-ravens/${card.suit}`;
}

function omenAnchor(card) {
  return slugify(cardTitle(card));
}

function omenSuitHtml(suit) {
  const meta = omen.suits[suit];
  const glyph = `<span class="suit-glyph">${meta.symbol}</span>`;
  const cards = suitCards(suit).map(card => [
    `<section class="omen-card">`,
    `<h3>${escapeHtml(cardTitle(card))}</h3>`,
    `<img class="omen-face" src="${cardImage(card)}" alt="${escapeHtml(cardTitle(card))}">`,
    cardBody(card),
    `</section>`
  ].join("\n")).join("\n");
  return [
    `<h1 class="suit-title">${glyph}${escapeHtml(meta.label)}${glyph}</h1>`,
    `<p class="kicker">${escapeHtml(meta.theme)}</p>`,
    cards
  ].join("\n");
}

function omenLegendHtml() {
  const order = ["hearts", "diamonds", "spades", "clubs", "joker"];
  const sections = order.map(suit => {
    const meta = omen.suits[suit];
    const items = suitCards(suit).map(card => {
      return `<li><span>${escapeHtml(card.rank)}</span> @UUID[${pageUuid(omenPageRef(card))}#${omenAnchor(card)}]{${escapeHtml(card.name)}}</li>`;
    }).join("");
    return `<section><h4>${escapeHtml(meta.label)} | ${escapeHtml(meta.theme)}</h4><ul>${items}</ul></section>`;
  }).join("");
  return `<div class="omen-legend">${sections}</div>`;
}

async function pageContent(page) {
  if (page.omenSuit) return omenSuitHtml(page.omenSuit);
  let html = await readFile(path.join(SRC, page.file), "utf8");
  html = html.replace("{{omen-legend}}", omenLegendHtml());
  return html;
}

function wrap(html, theme) {
  const classes = ["smd", theme ? `smd-${theme}` : null].filter(Boolean).join(" ");
  return `<div class="${classes}">\n${resolve(html).trim()}\n</div>`;
}

async function buildJournals() {
  const docs = [];
  docs.push({
    _id: ids.journalFolder,
    name: "Strahd Must Die",
    type: "JournalEntry",
    description: "",
    folder: null,
    sorting: "m",
    sort: 0,
    color: THEME_COLOR,
    flags: {},
    _stats: stats(),
    _key: `!folders!${ids.journalFolder}`
  });

  for (const [index, chapter] of book.entries()) {
    const entryId = ids.entries.get(chapter.slug);
    const pages = [];
    for (const [pageIndex, page] of chapter.pages.entries()) {
      const pageId = ids.pages.get(`${chapter.slug}/${page.slug}`);
      const base = {
        _id: pageId,
        name: page.name,
        sort: (pageIndex + 1) * 100000,
        ownership: { default: -1 },
        flags: {},
        system: {},
        title: { show: false, level: 1 },
        _stats: stats(),
        _key: `!journal.pages!${entryId}.${pageId}`
      };
      if (page.type === "image") {
        pages.push({ ...base, type: "image", src: `${MODULE_PATH}/${page.src}`, image: { caption: "" } });
      } else {
        const html = await pageContent(page);
        pages.push({ ...base, type: "text", text: { content: wrap(html, page.theme), format: 1 } });
      }
    }
    docs.push({
      _id: entryId,
      name: chapter.name,
      pages,
      folder: ids.journalFolder,
      sort: (index + 1) * 100000,
      ownership: { default: 0 },
      flags: { [MODULE_ID]: { themed: true } },
      _stats: stats(),
      _key: `!journal!${entryId}`
    });
  }
  return docs;
}

function buildCards() {
  const deckId = ids.decks.get("omen-deck");
  const back = `${MODULE_PATH}/assets/cards/back.webp`;
  const cards = omen.cards.map((card, index) => {
    const cardId = makeId(`card:${cardSlug(card)}`);
    const link = `@UUID[${pageUuid(omenPageRef(card))}#${omenAnchor(card)}]{${cardTitle(card)}}`;
    return {
      _id: cardId,
      name: cardTitle(card),
      description: wrap(`<h3>${escapeHtml(cardTitle(card))}</h3>${cardBody(card)}<p class="center">${link}</p>`),
      type: "base",
      system: {},
      suit: card.suit,
      value: card.value,
      back: { name: "", text: "", img: back },
      faces: [{ name: cardTitle(card), text: escapeHtml(card.passive), img: cardImage(card) }],
      face: 0,
      drawn: false,
      origin: null,
      width: 2,
      height: 3,
      rotation: 0,
      sort: (index + 1) * 1000,
      flags: {},
      _stats: stats(),
      _key: `!cards.cards!${deckId}.${cardId}`
    };
  });
  return [{
    _id: deckId,
    name: "The Conspiracy of Ravens",
    type: "deck",
    description: resolve(`<p>The 54 <strong>OMEN CARDS</strong> of Strahd Must Die. When the players win the favor of the ravens, deal a card to their hand – it goes into their <strong>VAULT</strong> and joins their <strong>LOADOUT</strong> after their next <strong>REST</strong>.</p><p>See @UUID[{{page:conspiracy-of-ravens/legend}}]{Legend of the Ravens}.</p>`),
    img: back,
    system: {},
    cards,
    width: 2,
    height: 3,
    rotation: 0,
    displayCount: true,
    folder: null,
    sort: 0,
    ownership: { default: 0 },
    flags: {},
    _stats: stats(),
    _key: `!cards!${deckId}`
  }];
}

function tableResult(tableId, key, result) {
  const resultId = makeId(`result:${key}`);
  return {
    _id: resultId,
    type: "text",
    name: result.name,
    description: resolve(result.description ?? ""),
    img: result.img ?? "icons/svg/d20-black.svg",
    weight: 1,
    range: result.range,
    drawn: false,
    documentUuid: null,
    flags: {},
    _stats: stats(),
    _key: `!tables.results!${tableId}.${resultId}`
  };
}

function buildTables() {
  const docs = tables.map((table, index) => {
    const tableId = ids.tables.get(table.slug);
    return {
      _id: tableId,
      name: table.name,
      img: `${MODULE_PATH}/${table.img}`,
      description: resolve(table.description),
      results: table.results.map((result, i) => tableResult(tableId, `${table.slug}:${i}`, { ...result, img: `${MODULE_PATH}/${table.img}` })),
      formula: table.formula,
      replacement: table.replacement,
      displayRoll: true,
      folder: null,
      sort: (index + 1) * 100000,
      ownership: { default: 0 },
      flags: {},
      _stats: stats(),
      _key: `!tables!${tableId}`
    };
  });

  const omenId = ids.tables.get("omen-cards");
  docs.push({
    _id: omenId,
    name: "Omen Cards",
    img: `${MODULE_PATH}/assets/cards/back.webp`,
    description: resolve(`<p>Draw an <strong>OMEN CARD</strong> from the Conspiracy of Ravens. Cards are drawn without replacement – reset the table to shuffle the omens back in. See @UUID[{{page:conspiracy-of-ravens/legend}}]{Legend of the Ravens}.</p>`),
    results: omen.cards.map((card, i) => tableResult(omenId, `omen:${cardSlug(card)}`, {
      name: cardTitle(card),
      img: cardImage(card),
      range: [i + 1, i + 1],
      description: `<p><strong>Passive:</strong> ${escapeHtml(card.passive)}</p><p>@UUID[${pageUuid(omenPageRef(card))}#${omenAnchor(card)}]{${escapeHtml(cardTitle(card))}}</p>`
    })),
    formula: `1d${omen.cards.length}`,
    replacement: false,
    displayRoll: true,
    folder: null,
    sort: (tables.length + 1) * 100000,
    ownership: { default: 0 },
    flags: {},
    _stats: stats(),
    _key: `!tables!${omenId}`
  });
  return docs;
}

async function writePack(name, docs) {
  const jsonDir = path.join(JSON_OUT, name);
  const packDir = path.join(PACKS_OUT, name);
  await rm(jsonDir, { recursive: true, force: true });
  await rm(packDir, { recursive: true, force: true });
  await mkdir(jsonDir, { recursive: true });
  for (const doc of docs) {
    const file = `${slugify(doc.name)}_${doc._id}.json`;
    await writeFile(path.join(jsonDir, file), `${JSON.stringify(doc, null, 2)}\n`, "utf8");
  }
  await compilePack(jsonDir, packDir, { log: false });
  console.log(`packs/${name}: ${docs.length} documents`);
}

await writePack("journals", await buildJournals());
await writePack("omen-deck", buildCards());
await writePack("tables", buildTables());
