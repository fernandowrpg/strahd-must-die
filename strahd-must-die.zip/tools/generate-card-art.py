import argparse
import json
import math
import pathlib
import re
import textwrap

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = pathlib.Path(__file__).resolve().parent.parent
RED = (209, 5, 30)
INK = (231, 229, 213)
BG = (16, 15, 19)
W, H = 500, 700

SUIT_PATHS = {
    "hearts": "M50 90 C 22 68 4 50 4 31 C 4 17 15 7 28 7 C 38 7 46 13 50 21 C 54 13 62 7 72 7 C 85 7 96 17 96 31 C 96 50 78 68 50 90 Z",
    "diamonds": "M50 4 L86 50 L50 96 L14 50 Z",
    "spades": "M50 6 C 72 30 95 45 95 63 C 95 76 85 84 74 84 C 66 84 59 80 55 74 C 56 82 60 89 66 94 L34 94 C 40 89 44 82 45 74 C 41 80 34 84 26 84 C 15 84 5 76 5 63 C 5 45 28 30 50 6 Z",
    "clubs": "M50 6 A 19 19 0 0 1 66 36 A 19 19 0 1 1 58 70 C 59 80 62 88 67 94 L33 94 C 38 88 41 80 42 70 A 19 19 0 1 1 34 36 A 19 19 0 0 1 50 6 Z",
    "joker": "M50 4 L61 37 L96 37 L68 58 L79 92 L50 71 L21 92 L32 58 L4 37 L39 37 Z",
}

RANK_SHORT = {"King": "K", "Queen": "Q", "Jack": "J", "Ace": "A", "Joker 1": "", "Joker 2": ""}


def svg_path_to_polygons(path, scale, offset, steps=24):
    tokens = re.findall(r"[MLCAZ]|-?\d+(?:\.\d+)?", path)
    polygons, current, i = [], [], 0
    pos = (0.0, 0.0)
    start = (0.0, 0.0)

    def tr(p):
        return (offset[0] + p[0] * scale, offset[1] + p[1] * scale)

    while i < len(tokens):
        cmd = tokens[i]
        i += 1
        if cmd == "M":
            pos = (float(tokens[i]), float(tokens[i + 1]))
            start = pos
            i += 2
            current = [tr(pos)]
        elif cmd == "L":
            pos = (float(tokens[i]), float(tokens[i + 1]))
            i += 2
            current.append(tr(pos))
        elif cmd == "C":
            p1 = (float(tokens[i]), float(tokens[i + 1]))
            p2 = (float(tokens[i + 2]), float(tokens[i + 3]))
            p3 = (float(tokens[i + 4]), float(tokens[i + 5]))
            i += 6
            for s in range(1, steps + 1):
                t = s / steps
                x = (1 - t) ** 3 * pos[0] + 3 * (1 - t) ** 2 * t * p1[0] + 3 * (1 - t) * t ** 2 * p2[0] + t ** 3 * p3[0]
                y = (1 - t) ** 3 * pos[1] + 3 * (1 - t) ** 2 * t * p1[1] + 3 * (1 - t) * t ** 2 * p2[1] + t ** 3 * p3[1]
                current.append(tr((x, y)))
            pos = p3
        elif cmd == "A":
            rx = float(tokens[i])
            large = int(tokens[i + 3])
            sweep = int(tokens[i + 4])
            end = (float(tokens[i + 5]), float(tokens[i + 6]))
            i += 7
            current.extend(tr(p) for p in arc_points(pos, end, rx, large, sweep, steps))
            pos = end
        elif cmd == "Z":
            pos = start
            polygons.append(current)
            current = []
    if current:
        polygons.append(current)
    return polygons


def arc_points(p0, p1, r, large, sweep, steps):
    x1, y1 = p0
    x2, y2 = p1
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2
    d2 = dx * dx + dy * dy
    r = max(r, math.sqrt(d2))
    sign = -1 if large == sweep else 1
    coef = sign * math.sqrt(max(0.0, (r * r - d2) / d2)) if d2 else 0
    cx = coef * dy + (x1 + x2) / 2
    cy = -coef * dx + (y1 + y2) / 2
    a1 = math.atan2(y1 - cy, x1 - cx)
    a2 = math.atan2(y2 - cy, x2 - cx)
    delta = a2 - a1
    if sweep and delta < 0:
        delta += 2 * math.pi
    if not sweep and delta > 0:
        delta -= 2 * math.pi
    return [(cx + r * math.cos(a1 + delta * s / steps), cy + r * math.sin(a1 + delta * s / steps)) for s in range(1, steps + 1)]


def draw_suit(image, suit, size, center, fill):
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    scale = size / 100
    offset = (center[0] - size / 2, center[1] - size / 2)
    for polygon in svg_path_to_polygons(SUIT_PATHS[suit], scale, offset):
        draw.polygon(polygon, fill=fill)
    image.alpha_composite(layer)


def suit_svg(suit, color="#d1051e"):
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">'
        '<rect x="2" y="2" width="116" height="116" rx="14" fill="#100f13" stroke="#5c0010" stroke-width="4"/>'
        f'<g transform="translate(14 14) scale(0.92)"><path d="{SUIT_PATHS[suit]}" fill="{color}"/></g>'
        "</svg>\n"
    )


def textured_background(texture):
    base = Image.new("RGBA", (W, H), BG + (255,))
    tex = texture.resize((W, int(texture.height * W / texture.width))).crop((0, 0, W, H)).convert("RGBA")
    base.alpha_composite(tex)
    vignette = Image.new("L", (W, H), 0)
    ImageDraw.Draw(vignette).ellipse((-W * 0.25, -H * 0.15, W * 1.25, H * 1.15), fill=255)
    vignette = vignette.filter(ImageFilter.GaussianBlur(70))
    dark = Image.new("RGBA", (W, H), (0, 0, 0, 230))
    dark.putalpha(Image.eval(vignette, lambda v: 230 - int(v * 0.9)))
    base.alpha_composite(dark)
    return base


def frame(draw):
    draw.rectangle((14, 14, W - 15, H - 15), outline=RED + (255,), width=3)
    draw.rectangle((24, 24, W - 25, H - 25), outline=RED + (120,), width=1)


def centered(draw, y, text, font, fill, spacing=0):
    if spacing:
        text = (" " * spacing).join(text)
    width = draw.textlength(text, font=font)
    draw.text(((W - width) / 2, y), text, font=font, fill=fill)


def fit_lines(draw, text, font_path, max_width, max_height, start=22, minimum=14):
    for size in range(start, minimum - 1, -1):
        font = ImageFont.truetype(font_path, size)
        set_weight(font, 300)
        chars = max(10, int(max_width / (size * 0.5)))
        lines = textwrap.wrap(text, chars)
        while lines and max(draw.textlength(l, font=font) for l in lines) > max_width and chars > 10:
            chars -= 2
            lines = textwrap.wrap(text, chars)
        if len(lines) * size * 1.35 <= max_height:
            return font, lines, size
    font = ImageFont.truetype(font_path, minimum)
    set_weight(font, 300)
    lines = textwrap.wrap(text, int(max_width / (minimum * 0.5)))
    keep = int(max_height / (minimum * 1.35))
    lines = lines[:keep]
    lines[-1] = lines[-1].rstrip(" .,;–") + "…"
    return font, lines, minimum


def set_weight(font, weight):
    try:
        font.set_variation_by_axes([weight])
    except Exception:
        pass


def card_face(card, suit, texture, fonts):
    image = textured_background(texture)
    draw = ImageDraw.Draw(image)
    draw_suit(image, card["suit"], 330, (W / 2, H / 2 - 10), RED + (38,))
    frame(draw)

    rank = RANK_SHORT.get(card["rank"], card["rank"])
    rank_font = ImageFont.truetype(fonts["title"], 58)
    for flip in (False, True):
        corner = Image.new("RGBA", (110, 150), (0, 0, 0, 0))
        cdraw = ImageDraw.Draw(corner)
        width = cdraw.textlength(rank, font=rank_font)
        if rank:
            cdraw.text(((110 - width) / 2, 0), rank, font=rank_font, fill=RED + (255,))
            draw_suit(corner, card["suit"], 38, (55, 102), RED + (255,))
        else:
            draw_suit(corner, card["suit"], 64, (55, 50), RED + (255,))
        if flip:
            corner = corner.rotate(180)
            image.alpha_composite(corner, (W - 34 - 110, H - 34 - 150))
        else:
            image.alpha_composite(corner, (34, 34))

    kicker = ImageFont.truetype(fonts["sans"], 18)
    set_weight(kicker, 600)
    centered(draw, 120, "OMEN", kicker, INK + (255,), spacing=2)

    lines = textwrap.wrap(card["name"], 12, break_long_words=False)
    size = 64
    name_font = ImageFont.truetype(fonts["title"], size)
    while size > 36 and max(draw.textlength(l, font=name_font) for l in lines) > W - 90:
        size -= 2
        name_font = ImageFont.truetype(fonts["title"], size)
    y = 225 - len(lines) * size * 0.56
    for line in lines:
        centered(draw, y, line, name_font, RED + (255,))
        y += int(size * 1.1)

    theme = ImageFont.truetype(fonts["sans"], 17)
    set_weight(theme, 600)
    centered(draw, y + 6, f"{suit['label']} | {suit['theme']}".upper(), theme, INK + (230,))

    top = max(330, int(y) + 40)
    font, text_lines, size = fit_lines(draw, card["passive"], fonts["sans"], W - 120, 505 - top - 26)
    label = ImageFont.truetype(fonts["sans"], 15)
    set_weight(label, 700)
    centered(draw, top, "PASSIVE", label, RED + (255,), spacing=1)
    ty = top + 26
    for line in text_lines:
        centered(draw, ty, line, font, INK + (255,))
        ty += int(size * 1.35)
    return image.convert("RGB")


def card_back(texture, ravens, logo, fonts):
    image = textured_background(texture)
    art = ravens.convert("RGBA")
    art = art.resize((int(art.width * H / art.height), H)).crop((0, 0, W, H))
    art.putalpha(80)
    image.alpha_composite(art)
    draw = ImageDraw.Draw(image)
    frame(draw)
    mark = logo.convert("RGBA")
    mark.thumbnail((400, 470))
    image.alpha_composite(mark, ((W - mark.width) // 2, 70))
    sans = ImageFont.truetype(fonts["sans"], 20)
    set_weight(sans, 600)
    centered(draw, H - 140, "CONSPIRACY OF RAVENS", sans, INK + (255,), spacing=1)
    small = ImageFont.truetype(fonts["sans"], 15)
    set_weight(small, 400)
    centered(draw, H - 105, "OMEN CARD", small, RED + (255,), spacing=1)
    return image.convert("RGB")


def main():
    parser = argparse.ArgumentParser(description="Generate the Omen Card faces, card back and suit icons.")
    parser.add_argument("--title-font", required=True, help="Path to UnifrakturCook-Bold.ttf")
    parser.add_argument("--sans-font", required=True, help="Path to JosefinSans[wght].ttf")
    args = parser.parse_args()
    fonts = {"title": args.title_font, "sans": args.sans_font}

    data = json.loads((ROOT / "src" / "omen-cards.json").read_text(encoding="utf-8"))
    texture = Image.open(ROOT / "assets" / "ui" / "texture.webp")
    out = ROOT / "assets" / "cards"
    out.mkdir(parents=True, exist_ok=True)

    for card in data["cards"]:
        slug = card_slug(card)
        card_face(card, data["suits"][card["suit"]], texture, fonts).save(out / f"{slug}.webp", "WEBP", quality=82, method=6)

    ravens = Image.open(ROOT / "assets" / "art" / "ravens.webp")
    logo = Image.open(ROOT / "assets" / "ui" / "logo.webp")
    card_back(texture, ravens, logo, fonts).save(out / "back.webp", "WEBP", quality=85, method=6)

    icons = ROOT / "assets" / "icons"
    icons.mkdir(parents=True, exist_ok=True)
    for suit in SUIT_PATHS:
        (icons / f"{suit}.svg").write_text(suit_svg(suit), encoding="utf-8")


def card_slug(card):
    return f"{card['suit']}-{card['rank']}".lower().replace(" ", "-")


if __name__ == "__main__":
    main()
